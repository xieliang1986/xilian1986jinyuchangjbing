document.addEventListener('DOMContentLoaded', function() {
    // 疾病数据
    const diseases = {
        'white-spot': {
            name: '白点病',
            description: '金鱼最常见的寄生虫病之一，由纤毛虫引起',
            symptoms: '鱼体、鳍和鳃上出现白色小点（直径约0.5-1mm），鱼会摩擦硬物，食欲减退，呼吸急促，严重时体表覆盖白色黏液',
            causes: '水温骤变、水质恶化、新鱼引入未检疫',
            treatment: [
                '缓慢提高水温至28-30℃（每天升温不超过2℃）',
                '使用白点净（含孔雀石绿或亚甲基蓝）按说明治疗',
                '每2天换水30%，补充药物',
                '治疗期间保持良好水质，停食或少量喂食',
                '治疗周期通常为5-7天'
            ]
        },
        'fin-rot': {
            name: '烂鳍病',
            description: '细菌感染引起的鳍部组织坏死',
            symptoms: '鳍边缘出现白色浑浊，逐渐溃烂变短，严重时鳍基部充血，可能继发水霉感染',
            causes: '水质不良、打架受伤、低温导致免疫力下降',
            treatment: [
                '改善水质，增加换水频率（每周2-3次，每次20-30%）',
                '使用黄粉或抗生素（如土霉素）药浴',
                '严重时可涂抹抗生素软膏于患处',
                '保持水温稳定在24-26℃',
                '添加0.3%盐辅助治疗'
            ]
        },
        'swim-bladder': {
            name: '鱼鳔失调症',
            description: '鱼鳔功能异常导致的游泳障碍',
            symptoms: '无法保持平衡，侧躺、倒立或腹部朝天，但仍能进食，通常无其他明显病症',
            causes: '先天性缺陷、喂食不当（过多干饲料）、水温骤变、细菌感染',
            treatment: [
                '停食2-3天，然后喂食煮熟的去皮豌豆',
                '降低水位至鱼体高度的2倍',
                '保持水温恒定（24-26℃）',
                '如因感染引起，需配合抗生素治疗',
                '避免喂食浮性饲料，改用沉底饲料'
            ]
        },
        'ich': {
            name: '水霉病',
            description: '真菌感染引起的疾病',
            symptoms: '体表出现棉絮状灰白色菌丝，常见于伤口或溃疡处，鱼只萎靡不振，食欲减退',
            causes: '低温（低于20℃）、鱼体受伤、水质不良',
            treatment: [
                '缓慢升温至26-28℃',
                '使用亚甲基蓝或专用水霉治疗剂',
                '严重感染可用孔雀石绿（注意剂量）',
                '保持水质清洁，增加换水频率',
                '添加0.5%盐辅助治疗'
            ]
        },
        'dropsy': {
            name: '腹水病',
            description: '细菌感染引起的严重内部疾病',
            symptoms: '腹部肿胀，鳞片竖立（松果状），眼球突出，肛门红肿，体色发暗，常沉底不动',
            causes: '水质极度恶化、细菌感染（多为革兰氏阴性菌）、内脏器官衰竭',
            treatment: [
                '隔离病鱼，防止传染',
                '使用抗生素（如氟苯尼考、恩诺沙星）',
                '添加0.5%盐减轻肾脏负担',
                '喂食含抗生素的药饵（如呋喃唑酮）',
                '早期治疗可能有效，晚期治愈率低'
            ]
        },
        'velvet': {
            name: '天鹅绒病',
            description: '由卵圆鞭毛虫引起的寄生虫病',
            symptoms: '体表出现金黄色或淡黄色粉状覆盖物，鳃部感染时呼吸急促，鱼摩擦硬物，严重时体表出血',
            causes: '新鱼引入未检疫、水质不良、温度变化大',
            treatment: [
                '避光治疗（寄生虫依赖光照）',
                '使用铜制剂（如螯合铜）按说明使用',
                '升温至28℃加速寄生虫生命周期',
                '每2天换水30%，补充药物',
                '治疗周期10-14天，确保彻底杀灭'
            ]
        }
    };

    // DOM元素
    const diseaseSelect = document.getElementById('disease-select');
    const diseaseInfo = document.getElementById('disease-info');
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    const imagePreview = document.getElementById('image-preview');

    // 疾病选择处理
    diseaseSelect.addEventListener('change', function() {
        const diseaseId = this.value;
        
        if (diseaseId) {
            displayDiseaseInfo(diseases[diseaseId]);
        } else {
            showPlaceholder();
        }
    });

    // 显示疾病信息
    function displayDiseaseInfo(disease) {
        diseaseInfo.innerHTML = `
            <div class="disease-detail">
                <h3>${disease.name}</h3>
                <div class="info-item">
                    <h4><i class="fas fa-info-circle"></i> 疾病描述</h4>
                    <p>${disease.description}</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-exclamation-triangle"></i> 症状</h4>
                    <p>${disease.symptoms}</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-virus"></i> 病因</h4>
                    <p>${disease.causes}</p>
                </div>
                <div class="info-item">
                    <h4><i class="fas fa-heartbeat"></i> 治疗方法</h4>
                    <ol class="treatment-steps">
                        ${disease.treatment.map(step => `<li>${step}</li>`).join('')}
                    </ol>
                </div>
            </div>
        `;
    }

    // 显示占位符
    function showPlaceholder() {
        diseaseInfo.innerHTML = `
            <div class="placeholder">
                <i class="fas fa-info-circle"></i>
                <p>请选择疾病或上传图片查看详细信息</p>
            </div>
        `;
    }

    // 图片上传处理
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#2193b0';
        this.style.backgroundColor = '#e6f7ff';
    });

    uploadArea.addEventListener('dragleave', function() {
        this.style.borderColor = '#6dd5ed';
        this.style.backgroundColor = '#f8fdff';
    });

    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        this.style.borderColor = '#6dd5ed';
        this.style.backgroundColor = '#f8fdff';
        
        if (e.dataTransfer.files.length) {
            handleImageUpload(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', function() {
        if (this.files.length) {
            handleImageUpload(this.files[0]);
        }
    });

    // 处理图片上传
    function handleImageUpload(file) {
        if (!file.type.match('image.*')) {
            alert('请上传图片文件！');
            return;
        }

        const reader = new FileReader();
        
        reader.onload = function(e) {
            imagePreview.innerHTML = `<img src="${e.target.result}" alt="病情图片">`;
            imagePreview.style.display = 'block';
            
            // 模拟图片分析结果
            setTimeout(() => {
                const randomDiseaseKey = Object.keys(diseases)[Math.floor(Math.random() * Object.keys(diseases).length)];
                displayDiseaseInfo(diseases[randomDiseaseKey]);
                
                // 添加分析结果提示
                diseaseInfo.insertAdjacentHTML('afterbegin', `
                    <div class="info-item">
                        <h4><i class="fas fa-search"></i> 图片分析结果</h4>
                        <p>系统分析显示您的金鱼可能患有 <strong>${diseases[randomDiseaseKey].name}</strong>，请参考以下治疗方案。</p>
                        <p style="font-size:0.9rem; color:#888; margin-top:8px;">（注：此为演示效果，实际应用需专业图像识别技术）</p>
                    </div>
                `);
            }, 1500);
        };
        
        reader.readAsDataURL(file);
    }
});